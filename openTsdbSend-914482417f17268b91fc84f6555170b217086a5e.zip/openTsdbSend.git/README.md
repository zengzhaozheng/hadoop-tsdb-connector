
public class MainTsdbSendWorker {

    public static void main(String[] args) {
        Set<OpenTsdbMetric> metrics = new HashSet<>();
        //topic����Ϊtopci.gamge.info
        //ע�⣺new Date().getTime()ΪÿСʱʱ�����10000Ϊ��topic��¼��
        OpenTsdbMetric m1 = new OpenTsdbMetric("topic.gamge.info2", new Date().getTime(), 10000);
        metrics.add(m1);

        MainTsdbSendWorker mainTsdbSendWorker = new MainTsdbSendWorker();
        String tsdbIP = "10.1.80.142";
        int tsdbPort = 4242;
        int batchSize = 8;
        mainTsdbSendWorker.sendMetric(tsdbIP,tsdbPort,batchSize,metrics);
    }

    public void sendMetric(String tsdbIP, int tsdbPort, int batchSize, Set<OpenTsdbMetric> metrics) {
        OpenTsdb tsdb = OpenTsdb.forService(tsdbIP, tsdbPort).withBatchSizeLimit(batchSize).create();
        tsdb.send(metrics);
    }


}