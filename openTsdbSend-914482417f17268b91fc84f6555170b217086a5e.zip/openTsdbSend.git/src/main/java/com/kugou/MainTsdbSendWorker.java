package com.kugou;

import java.util.*;

/**
 * Created by zhaozhengzeng on 2015/10/30.
 */
public class MainTsdbSendWorker {

    ////例子
    public static void main(String[] args) {
        Set<OpenTsdbMetric> metrics = new HashSet<>();
        Map<String, String> tagSet1 = new HashMap<>();
        //此标志位上报点1
        tagSet1.put("storageFlat","kafkaInput");
        //topic名称为topci.gamge.info,10000为每天该topic上报条数,注意new Date().getTime()要改为当天整点时间戳
        OpenTsdbMetric m1 = new OpenTsdbMetric("topic.gamge.info3", new Date().getTime()/1000, Integer.parseInt(args[0]), tagSet1);
        metrics.add(m1);

        MainTsdbSendWorker mainTsdbSendWorker = new MainTsdbSendWorker();
        String tsdbIP = "10.1.80.142";
        int tsdbPort = 4242;
        int batchSize = 8;
        mainTsdbSendWorker.sendMetric(tsdbIP,tsdbPort,batchSize,metrics);
    }

    public void sendMetric(String tsdbIP, int tsdbPort, int batchSize, Set<OpenTsdbMetric> metrics) {
        OpenTsdb tsdb = OpenTsdb.forService(tsdbIP, tsdbPort).withBatchSizeLimit(batchSize).create();
        tsdb.send(metrics);
    }


}
